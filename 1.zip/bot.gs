var TOKEN = "bhMDrvleSNIAV5djrdcywK+3twGH2ieIoA0Gz8rGfMM5rWvf567l286zOaw3KiHfAn/Tj9MXiMutjRUa0cETpzhV6Z8H0SqfqQbdGUu3TTk7xuXK+JZIGCnz17oGQW5Fhl9JDtnJIALIz7P0pCRSIQdB04t89/1O/w1cDnyilFU=";
// DÁN CHANNEL ACCESS TOKEN CỦA LINE BOT VÀO ĐÂY
// Khuyến nghị: sau khi chạy ổn định, nên chuyển token vào Script Properties để an toàn hơn.

// LIFF Form giao việc
var LIFF_ID = "2010371497-R9x4l665";
var LIFF_URL = "https://liff.line.me/" + LIFF_ID;

// ==========================================
// 0. MENU TRÊN GOOGLE SHEET
// ==========================================
function onOpen() {
  // Tự động cấu hình LIFF ID của bạn vào hệ thống
  PropertiesService.getScriptProperties().setProperty('LIFF_ID', '2010371497-R9x4l665');
  
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('🤖 LINE BOT')
      .addItem('1. Khởi tạo Bảng Dữ Liệu', 'SETUP_KHOI_TAO_HETHONG')
      .addItem('2. Dọn dẹp dòng rác/trống', 'XOA_DONG_RÁC')
      .addSeparator()
      .addItem('📸 3. Up Ảnh & Lấy Link', 'SHOW_UPLOAD_DIALOG')
      .addItem('📱 4. Mở Form Giao Việc (LINE LIFF)', 'OPEN_LIFF_FORM')
      .addItem('🔍 5. Chạy Quét Việc Thủ Công & Xem Log', 'CHAY_QUET_VIEC_THU_CONG')
      .addSeparator()
      .addItem('🧹 Làm sạch Sự kiện', 'LAM_SACH_SU_KIEN')
      .addItem('🧹 Làm sạch Tương tác', 'LAM_SACH_TUONG_TAC')
      .addSeparator()
      .addItem('🎛️ Tạo Rich Menu', 'SETUP_RICH_MENU')
      .addItem('🖼️ Upload ảnh Rich Menu', 'UPLOAD_RICH_MENU_IMAGE_FROM_DRIVE')
      .addItem('✅ Đặt Rich Menu mặc định', 'SET_DEFAULT_RICH_MENU')
      .addSeparator()
      .addItem('🧪 Test LIFF URL', 'TEST_LIFF_URL')
      .addToUi();
}

function SETUP_KHOI_TAO_HETHONG() {
  var ss = getSpreadsheet();
  var sheetsConfig = {
    "Sự kiện": ["Tên sự kiện", "Nội dung", "Ngày giờ gửi", "Link ảnh đính kèm", "Lặp lại", "Nhóm nhận", "Người phụ trách", "Tần suất (phút)", "Hình thức xác nhận", "Độ ưu tiên", "Người xác nhận", "Trạng thái", "Lần nhắc cuối", "Số lần nhắc", "Link Ảnh Nghiệm Thu"],
    "ID_Group": ["Tên Group", "ID Group"],
    "ID_Member": ["Tên Line", "ID Line"],
    "Tương Tác": ["Ngày", "ID Group", "ID Line", "Tên Line", "Văn bản", "Sticker", "Ảnh", "Tổng"],
    "Chatbot": ["Từ khóa", "Văn bản trả lời", "Link ảnh Google Drive"],
    "Link_img": ["Tên Ảnh", "Link Trực Tiếp"]
  };

  for (var sheetName in sheetsConfig) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) sheet = ss.insertSheet(sheetName);
    var headers = sheetsConfig[sheetName];
    var range = sheet.getRange(1, 1, 1, headers.length);
    range.setValues([headers]);
    range.setFontWeight("bold").setBackground("#d9ead3"); 
    sheet.setFrozenRows(1);         
  }
  var defaultSheet = ss.getSheetByName("Trang tính1") || ss.getSheetByName("Sheet1");
  if (defaultSheet && ss.getSheets().length > 1) ss.deleteSheet(defaultSheet);
  
  // Tự động tạo trigger quét sự kiện nhắc việc mỗi phút
  taoTriggerQuetSuKien();
  
  SpreadsheetApp.getUi().alert("✅ Đã cập nhật hệ thống, thêm sheet Link_img và tự động kích hoạt Trình Nhắc Việc mỗi phút thành công!");
}

function taoTriggerQuetSuKien() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'checkAndSendLineMessage') {
      ScriptApp.deleteTrigger(triggers[i]);
    }
  }
  ScriptApp.newTrigger('checkAndSendLineMessage')
      .timeBased()
      .everyMinutes(1)
      .create();
}



// ==========================================
// TÍNH NĂNG 4: UP ẢNH VÀ LẤY LINK
// ==========================================
function SHOW_UPLOAD_DIALOG() {
  var html = HtmlService.createHtmlOutputFromFile('UploadUI').setWidth(500).setHeight(450).setSandboxMode(HtmlService.SandboxMode.IFRAME);
  SpreadsheetApp.getUi().showModalDialog(html, "📤 Tải ảnh lên hệ thống");
}

function processUpload(data, name) {
  var folderName = "BOT - LINE";
  var folders = DriveApp.getFoldersByName(folderName);
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(folderName);
  folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  var contentType = data.substring(5, data.indexOf(';'));
  var bytes = Utilities.base64Decode(data.split(',')[1]);
  var blob = Utilities.newBlob(bytes, contentType, name);
  var file = folder.createFile(blob);
  
  var fileId = file.getId();
  var directLink = "https://lh3.googleusercontent.com/d/" + fileId;

  var sheet = getSpreadsheet().getSheetByName("Link_img");
  if(sheet) sheet.appendRow([name, directLink]);
  
  return { name: name, link: directLink };
}

// ==========================================
// CÁC HÀM CŨ (NHẮC VIỆC, WEBHOOK, LƯU DỮ LIỆU...)
// ==========================================
function checkAndSendLineMessage() {
  writeLog("Bắt đầu quét sự kiện nhắc việc...", "INFO");
  try {
    var sheet = getSpreadsheet().getSheetByName("Sự kiện");
    if (!sheet) {
      writeLog("Không tìm thấy sheet 'Sự kiện'", "WARN");
      return;
    }
    var lastRow = sheet.getLastRow();
    if (lastRow < 2) {
      writeLog("Không có sự kiện nào trong danh sách.", "INFO");
      return;
    }
    
    var data = sheet.getRange(2, 1, lastRow - 1, 15).getValues(); 
    var currentTime = new Date();
    var processedCount = 0;
    
    for (var i = 0; i < data.length; i++) {
      var row = data[i], rowIndex = i + 2; 
      
      // Bỏ qua dòng trống hoặc đã gửi
      if (String(row[0]).trim() === "") continue;
      if (row[11] === "Đã gửi") continue;
      
      var tenSuKien = row[0];Hoàn
      var idG = row[5];
      var idNV = row[6];
      var tanSuat = parseInt(row[7]) || 15;
      var hinhThucXN = String(row[8]).trim();
      var uuTien = row[9];
      
      writeLog("Đang xử lý sự kiện: '" + tenSuKien + "' (Dòng " + rowIndex + ")", "INFO");
      
      // Parse ngày giờ gửi
      var tgGui = convertToDate(row[2]);
      if (!tgGui) {
        writeLog("❌ Lỗi: Ngày giờ gửi không hợp lệ ở Dòng " + rowIndex + ": '" + row[2] + "'", "WARN");
        continue;
      }
      
      if (idG === "") {
        writeLog("⚠️ Lỗi: Không có ID Nhóm nhận ở Dòng " + rowIndex, "WARN");
        continue;
      }
      
      // Kiểm tra đến giờ gửi chưa
      if (currentTime >= tgGui) {
        var hinhAnh = chuyenDoiLinkDrive(row[3]); 
        var lanNhacCuoi = convertToDate(row[12]) || new Date(0);
        var soLan = parseInt(row[13]) || 0;
        
        // Lấy thông tin Tên Nhóm và Tên Thành Viên để ghi log chi tiết
        var groupName = getGroupName(idG);
        var memberName = idNV ? getUserName(idNV, idG) : "Không có";
        
        if (hinhThucXN !== "Không" && hinhThucXN !== "") {
          var minsDiff = (currentTime - lanNhacCuoi) / 60000;
          if (minsDiff >= tanSuat || lanNhacCuoi.getTime() === 0) {
            soLan += 1;
            writeLog("Gửi tin nhắn nhắc việc: '" + tenSuKien + "' lần thứ " + soLan + " (Dòng " + rowIndex + ") | Nhóm: '" + groupName + "' | Phụ trách: '" + memberName + "'", "INFO");
            try {
              sendLinePush(idG, tenSuKien, row[1], hinhAnh, hinhThucXN, rowIndex, idNV, soLan, uuTien);
              sheet.getRange(rowIndex, 12).setValue("Chờ xác nhận");
              sheet.getRange(rowIndex, 13).setValue(currentTime);
              sheet.getRange(rowIndex, 14).setValue(soLan);
              processedCount++;
            } catch (err) {
              writeLog("❌ Lỗi gửi LINE API (Dòng " + rowIndex + "): " + err.toString(), "ERROR");
            }
          } else {
            writeLog("Nhắc việc '" + tenSuKien + "' (Dòng " + rowIndex + ") đang chờ cách lần cuối " + Math.round(minsDiff) + " phút / tần suất " + tanSuat + " phút", "INFO");
          }
        } else if (hinhThucXN === "Không") {
          writeLog("Gửi tin nhắn thông báo (Không xác nhận): '" + tenSuKien + "' (Dòng " + rowIndex + ") | Nhóm: '" + groupName + "' | Phụ trách: '" + memberName + "'", "INFO");
          try {
            sendLinePush(idG, tenSuKien, row[1], hinhAnh, "Không", rowIndex, idNV, soLan, uuTien);
            sheet.getRange(rowIndex, 12).setValue("Đã gửi");
            processedCount++;
            
            // Xử lý lặp lại
            if (row[4] !== "Không" && row[4] !== "") {
              try {
                taoDongTiepTheo(sheet, rowIndex);
                writeLog("Đã tạo dòng lặp lại '" + row[4] + "' cho sự kiện '" + tenSuKien + "'", "INFO");
              } catch (repeatErr) {
                writeLog("❌ Lỗi khi tạo dòng lặp lại (Dòng " + rowIndex + "): " + repeatErr.toString(), "ERROR");
              }
            }
          } catch (err) {
            writeLog("❌ Lỗi gửi LINE API (Dòng " + rowIndex + "): " + err.toString(), "ERROR");
          }
        }
      } else {
        var diffSecs = Math.round((tgGui - currentTime) / 1000);
        writeLog("Sự kiện '" + tenSuKien + "' chưa tới giờ gửi. (Còn " + diffSecs + " giây)", "INFO");
      }
    }
    writeLog("Hoàn thành quét sự kiện. Số lượng tin đã xử lý: " + processedCount, "INFO");
  } catch (e) {
    writeLog("❌ Lỗi hệ thống trong checkAndSendLineMessage: " + e.toString(), "ERROR");
  }
}

function taoDongTiepTheo(sheet, rowIndex) {
  var r = sheet.getRange(rowIndex, 1, 1, 10).getValues()[0];
  var d = convertToDate(r[2]);
  if (!d) {
    writeLog("⚠️ Lỗi lặp lại: Ngày giờ gốc không hợp lệ ở Dòng " + rowIndex + ": " + r[2], "ERROR");
    return;
  }
  if (r[4] === "Hàng giờ") d.setHours(d.getHours() + 1);
  else if (r[4] === "Hàng ngày") d.setDate(d.getDate() + 1);
  else if (r[4] === "Hàng tuần") d.setDate(d.getDate() + 7);
  var newData = [r[0], r[1], d, r[3], r[4], r[5], r[6], r[7], r[8], r[9], "", "", "", "", ""];
  ghiDuLieuThongMinh(sheet, newData);
}

function ghiDuLieuThongMinh(sheet, dataArray) {
  var colA = sheet.getRange("A:A").getValues();
  var insertRow = sheet.getLastRow() + 1;
  for (var i = 1; i < colA.length; i++) { if (String(colA[i][0]).trim() === "") { insertRow = i + 1; break; } }
  sheet.getRange(insertRow, 1, 1, 15).clearContent();
  sheet.getRange(insertRow, 1, 1, dataArray.length).setValues([dataArray]);
}

function doPost(e) {
  try {
    var postData = JSON.parse(e.postData.contents);
    
    // Nếu là API request từ LIFF Form
    if (postData && postData.action === "createTask") {
      var result = createTaskFromLIFF(postData.data);
      return ContentService.createTextOutput(JSON.stringify(result))
          .setMimeType(ContentService.MimeType.JSON);
    }
    
    var events = postData.events;
    if (!events || events.length === 0) {
      return ContentService.createTextOutput(JSON.stringify({content: "ok"}))
          .setMimeType(ContentService.MimeType.JSON);
    }
    
    var ss = getSpreadsheet();
    for (var i = 0; i < events.length; i++) {
      var event = events[i];
      try {
        if (event.type === "message") {
          var uId = event.source.userId, gId = event.source.groupId, msgType = event.message.type;
          
          // Tự động đăng ký Thành viên / Nhóm
          var name = "Nhân viên";
          try {
            if (uId) {
              var sMem = ss.getSheetByName("ID_Member");
              var memValues = sMem.getDataRange().getValues();
              var existingRow = memValues.find(r => r[1] === uId);
              if (existingRow) {
                name = existingRow[0];
              } else {
                name = getUserName(uId, gId);
                sMem.appendRow([name, uId]); 
              }
            }
            if (gId) {
              var sG = ss.getSheetByName("ID_Group");
              if (!sG.getDataRange().getValues().some(r => r[1] === gId)) { 
                sG.appendRow([getGroupName(gId), gId]); 
              }
            }
          } catch (err) {
            writeLog("Lỗi đăng ký TV/Nhóm: " + err.toString(), "ERROR");
          }
          
          // Xử lý tin nhắn text ở cả chat riêng và nhóm
          if (msgType === "text") {
            var text = event.message.text.trim().toLowerCase();
            
            // Log webhook nhận text
            try {
              writeLog("Webhook text: " + text + " | userId=" + uId + " | groupId=" + gId, "INFO");
            } catch (err) {}
            
            // 1. Trợ giúp cú pháp
            if (["/help", "help"].indexOf(text) !== -1) {
              replyHelp(event.replyToken);
              continue;
            }
            
            // 2. Hướng dẫn / giới thiệu BOT
            if (["/hd", "/huongdan", "hướng dẫn", "huong dan"].indexOf(text) !== -1) {
              replyHuongDanBot(event.replyToken);
              continue;
            }
            
            // 3. Mở form giao việc
            if ([
              "/link", "/tao", "/do", "/gv",
              "/giao", "link", "tạo việc", "tao viec",
              "giao việc", "giao viec", "mở giao việc", "mo giao viec"
            ].indexOf(text) !== -1) {
              replyGiaoForm(event.replyToken);
              continue;
            }
            
            // 4. Tương tác hôm nay
            if ([
              "/tthomnay", "/tuongtac", "tương tác", "tuong tac",
              "tương tác hôm nay", "tuong tac hom nay",
              "/homnay", "hôm nay", "hom nay", "/tthn"
            ].indexOf(text) !== -1) {
              if (gId) {
                guiBaoCaoTuongTac(gId, event.replyToken, 1);
              } else {
                sendLineReply(event.replyToken, "📌 Lệnh này dùng tốt nhất trong nhóm. Vui lòng dùng trong nhóm cần xem tương tác.");
              }
              continue;
            }
            
            // 5. Tương tác 7 ngày
            if ([
              "/tt7ngay", "tương tác 7 ngày", "tuong tac 7 ngay",
              "/7ngay", "7 ngày", "7 ngay", "/ttt"
            ].indexOf(text) !== -1) {
              if (gId) {
                guiBaoCaoTuongTac(gId, event.replyToken, 7);
              } else {
                sendLineReply(event.replyToken, "📅 Lệnh này dùng tốt nhất trong nhóm. Vui lòng dùng trong nhóm cần xem tương tác 7 ngày.");
              }
              continue;
            }
            
            // 6. Lấy ID
            if (["/id", "id", "lấy id", "lay id"].indexOf(text) !== -1) {
              if (gId) {
                sendLineReply(event.replyToken, "🆔 Group ID:\n" + gId + "\n\n👤 User ID:\n" + uId);
              } else {
                sendLineReply(event.replyToken, "👤 User ID:\n" + uId);
              }
              continue;
            }
            
            // 7. Gửi ảnh hướng dẫn
            if (text === "/anh") {
              sendLineReply(event.replyToken, "📸 Khi công việc yêu cầu ảnh: bấm nút ‘Gửi ảnh nghiệm thu’, sau đó gửi ảnh trực tiếp trong nhóm này.");
              continue;
            }
            
            // 7. Tra cứu Chatbot
            var sChat = ss.getSheetByName("Chatbot");
            if (sChat) {
              var cData = sChat.getDataRange().getValues();
              var foundChatbot = false;
              for (var k = 1; k < cData.length; k++) {
                if (String(cData[k][0]).trim().toLowerCase() === text) {
                  sendBotReply(event.replyToken, cData[k][1], cData[k][2]);
                  foundChatbot = true;
                  break;
                }
              }
              if (foundChatbot) continue;
            }
          }
          
          // Xử lý ảnh nghiệm thu (Chỉ chạy trong nhóm)
          if (msgType === "image" && gId) {
            var sEv = ss.getSheetByName("Sự kiện");
            var evData = sEv.getDataRange().getValues();
            for (var j = 1; j < evData.length; j++) {
              if (evData[j][5] === gId && evData[j][11] === "Chờ gửi ảnh" && evData[j][10] === name) {
                var imgUrl = luuAnhVaoDrive(event.message.id, name);
                sEv.getRange(j+1, 12).setValue("Đã gửi"); 
                sEv.getRange(j+1, 15).setValue(imgUrl);
                if (evData[j][4] !== "Không") taoDongTiepTheo(sEv, j+1);
                sendLineReply(event.replyToken, "📸 Đã nghiệm thu ảnh!"); 
                break;
              }
            }
          }
          
          // Cập nhật tương tác nhóm
          if (gId) {
            capNhatTuongTac(gId, uId, name, msgType);
          }
        }
        
        if (event.type === "postback") {
          var d = event.postback.data, rIdx = parseInt(d.split("&row=")[1]), sEv = ss.getSheetByName("Sự kiện");
          var uName = getUserName(event.source.userId, event.source.groupId);
          if (sEv.getRange(rIdx, 12).getValue() !== "Đã gửi") {
            if (d.includes("action=hoantat")) {
              sEv.getRange(rIdx, 11).setValue(uName); sEv.getRange(rIdx, 12).setValue("Đã gửi");
              if (sEv.getRange(rIdx, 5).getValue() !== "Không") taoDongTiepTheo(sEv, rIdx);
              sendLineReply(event.replyToken, "🎉 " + uName + " đã xong!");
            } else if (d.includes("action=chupanh")) {
              sEv.getRange(rIdx, 11).setValue(uName); sEv.getRange(rIdx, 12).setValue("Chờ gửi ảnh");
              sendLineReply(event.replyToken, "📸 Mời bạn gửi ảnh!");
            }
          }
        }
      } catch (errEvent) {
        try {
          writeLog("Lỗi xử lý sự kiện: " + errEvent.toString(), "ERROR");
        } catch (e) {}
      }
    }
    return ContentService.createTextOutput(JSON.stringify({content: "ok"}))
        .setMimeType(ContentService.MimeType.JSON);
  } catch (errGlobal) {
    try {
      writeLog("Lỗi toàn cục doPost: " + errGlobal.toString(), "ERROR");
    } catch (e) {}
    return ContentService.createTextOutput(JSON.stringify({content: "error", message: errGlobal.toString()}))
        .setMimeType(ContentService.MimeType.JSON);
  }
}

function getGroupName(groupId) {
  try { return JSON.parse(UrlFetchApp.fetch("https://api.line.me/v2/bot/group/" + groupId + "/summary", { "headers": { "Authorization": "Bearer " + TOKEN } }).getContentText()).groupName; } catch (e) { return "Nhóm cũ"; }
}

function luuAnhVaoDrive(messageId, userName) {
  var res = UrlFetchApp.fetch("https://api-data.line.me/v2/bot/message/" + messageId + "/content", { "headers": { "Authorization": "Bearer " + TOKEN } });
  var folder = DriveApp.getFoldersByName("Ảnh Nghiệm Thu BOT").hasNext() ? DriveApp.getFoldersByName("Ảnh Nghiệm Thu BOT").next() : DriveApp.createFolder("Ảnh Nghiệm Thu BOT");
  folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return folder.createFile(res.getBlob().setName(userName + "_" + new Date().getTime() + ".jpg")).getUrl();
}

function chuyenDoiLinkDrive(url) {
  if (!url) return "";
  var match = String(url).match(/\/d\/([a-zA-Z0-9_-]+)/) || String(url).match(/id=([a-zA-Z0-9_-]+)/);
  return match ? "https://lh3.googleusercontent.com/d/" + match[1] : url; 
}

function sendBotReply(token, txt, imgUrl) {
  var msgs = [];
  if (txt) msgs.push({ type: "text", text: String(txt) });
  if (imgUrl) {
    var dl = chuyenDoiLinkDrive(imgUrl);
    msgs.push({
      type: "image",
      originalContentUrl: dl,
      previewImageUrl: dl
    });
  }

  if (msgs.length === 0) {
    msgs.push({ type: "text", text: "Bot chưa có nội dung trả lời cho từ khóa này." });
  }

  replyMessages(token, msgs, "LINE chatbot reply");
}


// ==========================================
// HÀM GỬI LINE & FIX LỖI TAG ĐÍCH DANH (CẬP NHẬT MỚI NHẤT)
// ==========================================
function sendLinePush(to, ten, noiDung, img, hinhThucXN, rIdx, tagId, soLan, uuTien) {
  var msgs = [];
  
  // 1. Xử lý Ảnh
  var cleanImg = String(img).trim();
  if (cleanImg !== "" && cleanImg.startsWith("http")) {
    msgs.push({"type": "image", "originalContentUrl": cleanImg, "previewImageUrl": cleanImg});
  }
  
  // 2. Xử lý Tag đích danh (Sử dụng tin nhắn textV2 với substitution)
  var alertTxt = (soLan >= 3) ? "🚨 QUÁ HẠN: Việc mới!" : "🔔 Bạn có công việc mới!";
  var cleanTagId = String(tagId || "").trim();

  if (/^U[a-fA-F0-9]{32}$/.test(cleanTagId)) {
    msgs.push({
      "type": "textV2",
      "text": "{m_1} " + alertTxt,
      "substitution": {
        "m_1": {
          "type": "mention",
          "mentionee": {
            "type": "user",
            "userId": cleanTagId
          }
        }
      }
    });
  } else {
    msgs.push({ "type": "text", "text": alertTxt });
  }

  // 3. Xử lý Thẻ Công việc (Flex Message nâng cấp)
  msgs.push(buildTaskFlexMessage(ten, noiDung, hinhThucXN, rIdx, soLan, uuTien));
  
  // Gửi API với Log chi tiết
  var payload = { "to": to, "messages": msgs };
  var res = UrlFetchApp.fetch("https://api.line.me/v2/bot/message/push", {
    method: "post",
    headers: {
      Authorization: "Bearer " + TOKEN,
      "Content-Type": "application/json"
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var body = res.getContentText();
  writeLog("LINE push response: " + code + " | " + body, code >= 200 && code < 300 ? "INFO" : "ERROR");

  if (code < 200 || code >= 300) {
    throw new Error("LINE API lỗi " + code + ": " + body);
  }
}

function buildTaskFlexMessage(ten, noiDung, hinhThucXN, rIdx, soLan, uuTien) {
  var isUrgent = String(uuTien).trim() === "GẤP";
  var colorTheme = isUrgent ? "#FF334B" : "#1DB446";
  var badgeText = isUrgent ? "GẤP" : "NHẮC VIỆC";
  var titleText = String(ten || "Công việc mới").trim();
  var bodyText = String(noiDung || "Không có nội dung chi tiết").trim();

  var bubble = {
    type: "bubble",
    size: "mega",
    header: {
      type: "box",
      layout: "vertical",
      paddingAll: "14px",
      backgroundColor: colorTheme,
      contents: [
        {
          type: "text",
          text: badgeText,
          size: "xs",
          color: "#FFFFFF",
          weight: "bold"
        },
        {
          type: "text",
          text: titleText,
          size: "md",
          color: "#FFFFFF",
          weight: "bold",
          wrap: true,
          margin: "sm"
        }
      ]
    },
    body: {
      type: "box",
      layout: "vertical",
      spacing: "md",
      paddingAll: "16px",
      contents: [
        {
          type: "text",
          text: bodyText,
          size: "sm",
          color: "#333333",
          wrap: true
        },
        {
          type: "separator",
          margin: "md"
        },
        {
          type: "box",
          layout: "vertical",
          spacing: "sm",
          margin: "md",
          contents: [
            {
              type: "box",
              layout: "baseline",
              contents: [
                { type: "text", text: "Xác nhận", size: "xs", color: "#888888", flex: 2 },
                { type: "text", text: String(hinhThucXN || "Không"), size: "xs", color: "#333333", flex: 4, wrap: true }
              ]
            },
            {
              type: "box",
              layout: "baseline",
              contents: [
                { type: "text", text: "Lần nhắc", size: "xs", color: "#888888", flex: 2 },
                { type: "text", text: String(soLan || 1), size: "xs", color: "#333333", flex: 4 }
              ]
            }
          ]
        }
      ]
    }
  };

  if (hinhThucXN === "Bấm nút" || hinhThucXN === "Có") {
    bubble.footer = {
      type: "box",
      layout: "vertical",
      paddingAll: "12px",
      contents: [
        {
          type: "button",
          style: "primary",
          color: colorTheme,
          height: "sm",
          action: {
            type: "postback",
            label: "Hoàn tất",
            data: "action=hoantat&row=" + rIdx
          }
        }
      ]
    };
  }

  if (hinhThucXN === "Gửi ảnh") {
    bubble.footer = {
      type: "box",
      layout: "vertical",
      paddingAll: "12px",
      contents: [
        {
          type: "button",
          style: "primary",
          color: "#FF9900",
          height: "sm",
          action: {
            type: "postback",
            label: "📸 Gửi ảnh nghiệm thu",
            data: "action=chupanh&row=" + rIdx
          }
        }
      ]
    };
  }

  return {
    type: "flex",
    altText: titleText,
    contents: bubble
  };
}


function replyMessages(token, messages, logName) {
  if (!token) {
    writeLog("Không có replyToken, không thể reply.", "ERROR");
    return;
  }

  var payload = {
    replyToken: token,
    messages: messages
  };

  var res = UrlFetchApp.fetch("https://api.line.me/v2/bot/message/reply", {
    method: "post",
    headers: {
      Authorization: "Bearer " + TOKEN,
      "Content-Type": "application/json"
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var body = res.getContentText();
  writeLog((logName || "LINE reply") + " response: " + code + " | " + body, code >= 200 && code < 300 ? "INFO" : "ERROR");

  if (code < 200 || code >= 300) {
    throw new Error("LINE reply lỗi " + code + ": " + body);
  }
}

function sendLinePush_Simple(to, txt) { UrlFetchApp.fetch("https://api.line.me/v2/bot/message/push", {"method":"post","headers":{"Authorization":"Bearer "+TOKEN,"Content-Type":"application/json"},"payload":JSON.stringify({"to":to,"messages":[{"type":"text","text":txt}]})}); }
function sendLineReply(token, txt) {
  replyMessages(token, [{ type: "text", text: String(txt || "") }], "LINE text reply");
}

function getUserName(uId, gId) { try { var url = gId ? "https://api.line.me/v2/bot/group/" + gId + "/member/" + uId : "https://api.line.me/v2/bot/profile/" + uId; return JSON.parse(UrlFetchApp.fetch(url, {"headers": {"Authorization": "Bearer " + TOKEN}})).displayName; } catch (e) { return "Nhân viên"; } }

function capNhatTuongTac(gId, uId, name, type) {
  var s = getSpreadsheet().getSheetByName("Tương Tác"), today = new Date().toDateString();
  var d = s.getDataRange().getValues(), rIdx = -1;
  for (var i = 1; i < d.length; i++) { if (d[i][0] === today && d[i][1] === gId && d[i][2] === uId) { rIdx = i + 1; break; } }
  var v = (type === "text") ? 1 : 0, st = (type === "sticker") ? 1 : 0, im = (type === "image") ? 1 : 0;
  if (rIdx === -1) s.appendRow([today, gId, uId, name, v, st, im, 1]);
  else { var r = d[rIdx-1]; s.getRange(rIdx, 5, 1, 4).setValues([[r[4]+v, r[5]+st, r[6]+im, r[7]+1]]); }
}

function guiBaoCaoTuongTac(gId, token, days) {
  var s = getSpreadsheet().getSheetByName("Tương Tác"), d = s.getDataRange().getValues(), stats = {};
  var start = new Date().getTime() - (days - 1) * 24 * 60 * 60 * 1000;
  for (var i = 1; i < d.length; i++) { if (d[i][1] === gId && new Date(d[i][0]).getTime() >= start) { var id = d[i][2]; if (!stats[id]) stats[id] = { n: d[i][3], v: 0, s: 0, i: 0, t: 0 }; stats[id].v += d[i][4]; stats[id].s += d[i][5]; stats[id].i += d[i][6]; stats[id].t += d[i][7]; } }
  var arr = Object.keys(stats).map(k => stats[k]).sort((a,b) => b.t - a.t);
  if (arr.length === 0) { sendLineReply(token, "Chưa có dữ liệu."); return; }
  var rep = "📊 TƯƠNG TÁC (" + (days===1?"HÔM NAY":"TUẦN") + ")\nName | T | S | I | Tổng\n";
  arr.forEach(r => { rep += r.n.substring(0,8) + " | " + r.v + " | " + r.s + " | " + r.i + " | " + r.t + "\n"; });
  sendLineReply(token, rep);
}



function layId(sN, name) {
  if (!name || String(name).includes("Chưa có")) return "";
  var d = getSpreadsheet().getSheetByName(sN).getDataRange().getValues(), sn = String(name).trim().toLowerCase().replace(/\s+/g, ' '); 
  for(var i=0; i<d.length; i++) { if(String(d[i][0]).trim().toLowerCase().replace(/\s+/g, ' ') === sn) return d[i][1]; }
  return "";
}

function LAM_SACH_SU_KIEN() { 
  var ss = getSpreadsheet();
  var s = ss.getSheetByName("Sự kiện"); 
  if (!s) { SpreadsheetApp.getUi().alert("❌ Không tìm thấy sheet 'Sự kiện'"); return; }
  if (s.getLastRow() > 1) s.getRange(2,1,s.getLastRow()-1,s.getLastColumn()).clearContent(); 
  SpreadsheetApp.getUi().alert("✅ Đã làm sạch toàn bộ dữ liệu trong sheet Sự kiện!");
}

function LAM_SACH_TUONG_TAC() { 
  var ss = getSpreadsheet();
  var s = ss.getSheetByName("Tương Tác") || ss.getSheetByName("Tương tác") || ss.getSheetByName("TuongTac"); 
  if (!s) { SpreadsheetApp.getUi().alert("❌ Không tìm thấy sheet 'Tương Tác'!"); return; }
  if (s.getLastRow() > 1) s.getRange(2,1,s.getLastRow()-1,s.getLastColumn()).clearContent(); 
  SpreadsheetApp.getUi().alert("✅ Đã làm sạch toàn bộ dữ liệu trong sheet Tương tác!");
}

function XOA_DONG_RÁC() { 
  var ss = getSpreadsheet();
  var s = ss.getSheetByName("Sự kiện"); 
  if (!s) return;
  var maxRows = s.getMaxRows();
  if (maxRows <= 1) { SpreadsheetApp.getUi().alert("🧹 Sheet Sự kiện sạch sẽ!"); return; }
  var d = s.getRange(1, 1, maxRows, 1).getValues(); 
  var count = 0; var numEmpty = 0;
  for (var i = maxRows - 1; i >= 1; i--) { 
    if (String(d[i][0]).trim() === "") { numEmpty++; } 
    else { if (numEmpty > 0) { s.deleteRows(i + 2, numEmpty); count += numEmpty; numEmpty = 0; } }
  }
  if (numEmpty > 0) { s.deleteRows(2, numEmpty); count += numEmpty; }
  if (count > 0) { s.insertRowAfter(s.getMaxRows()); SpreadsheetApp.getUi().alert("⚡ Đã dọn dẹp SIÊU TỐC " + count + " dòng rác!"); } 
  else { SpreadsheetApp.getUi().alert("🧹 Sheet Sự kiện đã sạch sẽ!"); }
}

// ==========================================
// TÍNH NĂNG LIFF: WEB APP GIAO VIỆC
// ==========================================
function doGet(e) {
  // Bỏ qua iframe sandbox, nếu gọi API lấy danh sách
  if (e && e.parameter && e.parameter.action === "getLists") {
    var data = getFormDataLists();
    return ContentService.createTextOutput(JSON.stringify(data))
        .setMimeType(ContentService.MimeType.JSON);
  }
  
  var template = HtmlService.createTemplateFromFile('liff');
  // Truyền URL Web App động vào template
  try {
    template.webAppUrl = ScriptApp.getService().getUrl();
  } catch(err) {
    template.webAppUrl = "";
  }
  
  return template.evaluate()
      .setTitle('📝 Giao Việc Nhanh - LINE BOT')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getSpreadsheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  if (ss) {
    // Tự động lưu trữ ID Spreadsheet khi có context
    PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', ss.getId());
    return ss;
  }
  
  var ssId = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (ssId) {
    try {
      return SpreadsheetApp.openById(ssId);
    } catch(e) {}
  }
  
  throw new Error("Không thể kết nối với Spreadsheet. Vui lòng mở Google Sheet và bấm chạy Menu '1. Khởi tạo Bảng Dữ Liệu' trước.");
}

function getFormDataLists() {
  var ss = getSpreadsheet();
  
  // Lấy danh sách nhóm
  var sGroup = ss.getSheetByName("ID_Group");
  var groups = [];
  if (sGroup && sGroup.getLastRow() > 1) {
    var gData = sGroup.getRange(2, 1, sGroup.getLastRow() - 1, 2).getValues();
    gData.forEach(function(row) {
      if (String(row[0]).trim() !== "") {
        groups.push({ name: row[0], id: row[1] });
      }
    });
  }
  
  // Lấy danh sách thành viên
  var sMember = ss.getSheetByName("ID_Member");
  var members = [];
  if (sMember && sMember.getLastRow() > 1) {
    var mData = sMember.getRange(2, 1, sMember.getLastRow() - 1, 2).getValues();
    mData.forEach(function(row) {
      if (String(row[0]).trim() !== "") {
        members.push({ name: row[0], id: row[1] });
      }
    });
  }
  
  return { groups: groups, members: members };
}

function createTaskFromLIFF(data) {
  try {
    var ss = getSpreadsheet();
    var sheetEvent = ss.getSheetByName("Sự kiện");
    if (!sheetEvent) return { success: false, message: "Không tìm thấy sheet 'Sự kiện'!" };
    
    var ten = String(data.ten || "").trim();
    var nd = String(data.noiDung || "").trim();
    var tgStr = String(data.ngayGio || "").trim();
    var la = String(data.linkAnh || "").trim();
    if (data.imageFile && data.imageFile.dataUrl) {
      la = saveLiffImageToDrive(data.imageFile);
    }
    var ll = String(data.lapLai || "Không").trim();
    var idG = String(data.idGroup || "").trim();
    var idNV = String(data.idMember || "").trim();
    var ts = parseInt(data.tanSuat, 10) || 15;
    var ht = String(data.hinhThucXN || "Không").trim();
    var ut = String(data.doUuTien || "Bình thường").trim();
    
    if (ten === "") return { success: false, message: "Tên sự kiện không được để trống!" };
    if (idG === "") return { success: false, message: "Vui lòng chọn Nhóm nhận!" };
    if (tgStr === "") return { success: false, message: "Vui lòng chọn Ngày giờ gửi!" };
    
    var dateVal = convertToDate(tgStr);
    if (!dateVal) return { success: false, message: "Ngày giờ gửi không hợp lệ!" };
    
    // Ghi dữ liệu vào sheet Sự kiện
    var rowData = [ten, nd, dateVal, la, ll, idG, idNV, ts, ht, ut, "", "", "", "", ""];
    ghiDuLieuThongMinh(sheetEvent, rowData);
    
    // Gửi ngay nếu công việc đã tới giờ, không cần chờ trigger 1 phút.
    checkAndSendLineMessage();
    
    return { success: true, message: "Đã tạo công việc và đã kiểm tra gửi LINE!" };
  } catch (e) {
    return { success: false, message: "Lỗi hệ thống: " + e.toString() };
  }
}

function OPEN_LIFF_FORM() {
  var url = LIFF_URL;
  var html = HtmlService.createHtmlOutput('<script>window.open("' + url + '", "_blank");google.script.host.close();</script>').setWidth(300).setHeight(100);
  SpreadsheetApp.getUi().showModalDialog(html, "🚀 Đang mở Form LIFF...");
}

// ==========================================
// HÀM HỖ TRỢ GHI LOG & PHÂN TÍCH NGÀY THÁNG MỚI
// ==========================================

function writeLog(message, type) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName("Logs");
    if (!sheet) {
      sheet = ss.insertSheet("Logs");
      sheet.appendRow(["Thời gian", "Loại", "Nội dung log"]);
      sheet.getRange(1, 1, 1, 3).setFontWeight("bold").setBackground("#d9ead3");
      sheet.setFrozenRows(1);
    }
    
    type = type || "INFO";
    var timeStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd HH:mm:ss");
    sheet.appendRow([timeStr, type, message]);
    
    // Giới hạn 1000 dòng log
    var lastRow = sheet.getLastRow();
    if (lastRow > 1000) {
      sheet.deleteRows(2, lastRow - 1000);
    }
  } catch (e) {
    Logger.log("Lỗi ghi log: " + e.toString());
  }
}

function convertToDate(dateVal) {
  if (!dateVal) return null;
  if (dateVal instanceof Date) {
    if (!isNaN(dateVal.getTime())) return dateVal;
    return null;
  }
  
  var str = String(dateVal).trim();
  if (str === "") return null;
  
  // 1. Thử phân tích chuẩn bằng Date API
  var d = new Date(str);
  if (!isNaN(d.getTime())) return d;
  
  // 2. Thử phân tích định dạng dd/mm/yyyy hh:mm:ss hoặc tương tự
  var matchDMY = str.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
  if (matchDMY) {
    var day = parseInt(matchDMY[1], 10);
    var month = parseInt(matchDMY[2], 10) - 1; // 0-indexed month
    var year = parseInt(matchDMY[3], 10);
    var hour = matchDMY[4] ? parseInt(matchDMY[4], 10) : 0;
    var minute = matchDMY[5] ? parseInt(matchDMY[5], 10) : 0;
    var second = matchDMY[6] ? parseInt(matchDMY[6], 10) : 0;
    var parsed = new Date(year, month, day, hour, minute, second);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  
  // 3. Thử phân tích định dạng yyyy-mm-dd hh:mm:ss
  var matchYMD = str.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/);
  if (matchYMD) {
    var year = parseInt(matchYMD[1], 10);
    var month = parseInt(matchYMD[2], 10) - 1;
    var day = parseInt(matchYMD[3], 10);
    var hour = matchYMD[4] ? parseInt(matchYMD[4], 10) : 0;
    var minute = matchYMD[5] ? parseInt(matchYMD[5], 10) : 0;
    var second = matchYMD[6] ? parseInt(matchYMD[6], 10) : 0;
    var parsed = new Date(year, month, day, hour, minute, second);
    if (!isNaN(parsed.getTime())) return parsed;
  }
  
  return null;
}

function CHAY_QUET_VIEC_THU_CONG() {
  writeLog("=== BẮT ĐẦU CHẠY THỦ CÔNG ===", "INFO");
  checkAndSendLineMessage();
  writeLog("=== KẾT THÚC CHẠY THỦ CÔNG ===", "INFO");
  
  var ui = SpreadsheetApp.getUi();
  ui.alert("✅ Đã chạy quét việc xong! Vui lòng kiểm tra sheet 'Logs' để xem chi tiết kết quả.");
}

// ==========================================
// HÀM HỖ TRỢ HƯỚNG DẪN & CHAT RIÊNG
// ==========================================
function buildHelpText() {
  return "🤖 CÚ PHÁP BOT NHẮC VIỆC\n\n" +
    "📝 /gv hoặc /link - Mở form giao việc\n" +
    "🆔 /id - Lấy ID nhóm hoặc cá nhân\n" +
    "📌 /tthomnay hoặc /tuongtac - Xem tương tác hôm nay\n" +
    "📅 /tt7ngay - Xem tương tác 7 ngày\n" +
    "📖 /hd hoặc /huongdan - Giới thiệu tính năng BOT\n" +
    "❓ /help - Xem cú pháp";
}

function replyHelp(token) {
  sendLineReply(token, buildHelpText());
}

function buildGiaoFormFlexMessage() {
  var bubble = {
    "type": "bubble",
    "size": "kilo",
    "body": {
      "type": "box",
      "layout": "vertical",
      "spacing": "md",
      "contents": [
        {
          "type": "text",
          "text": "📝 GIAO VIỆC NHANH",
          "weight": "bold",
          "color": "#1DB446",
          "size": "md"
        },
        {
          "type": "text",
          "text": "Bấm nút bên dưới để mở form nhập thông tin giao việc.",
          "size": "xs",
          "color": "#666666",
          "wrap": true
        }
      ]
    },
    "footer": {
      "type": "box",
      "layout": "vertical",
      "contents": [
        {
          "type": "button",
          "style": "primary",
          "color": "#1DB446",
          "height": "sm",
          "action": {
            "type": "uri",
            "label": "Mở Form",
            "uri": LIFF_URL
          }
        }
      ]
    }
  };
  return {
    "type": "flex",
    "altText": "Mở Form Giao Việc",
    "contents": bubble
  };
}

function replyGiaoForm(token) {
  var flexMsg = {
    type: "flex",
    altText: "Mở form giao việc",
    contents: {
      type: "bubble",
      size: "kilo",
      body: {
        type: "box",
        layout: "vertical",
        spacing: "md",
        contents: [
          {
            type: "text",
            text: "📝 GIAO VIỆC NHANH",
            weight: "bold",
            size: "md",
            color: "#1DB446",
            wrap: true
          },
          {
            type: "text",
            text: "Bấm nút bên dưới để mở form giao việc.",
            size: "sm",
            color: "#555555",
            wrap: true
          },
          {
            type: "text",
            text: "Nếu bấm nút báo lỗi hệ thống, hãy kiểm tra lại cấu hình LIFF Endpoint trong LINE Developers.",
            size: "xxs",
            color: "#999999",
            wrap: true,
            margin: "sm"
          }
        ]
      },
      footer: {
        type: "box",
        layout: "vertical",
        spacing: "sm",
        contents: [
          {
            type: "button",
            style: "primary",
            color: "#1DB446",
            height: "sm",
            action: {
              type: "uri",
              label: "Mở form giao việc",
              uri: LIFF_URL
            }
          }
        ]
      }
    },
    quickReply: {
      items: [
        {
          type: "action",
          action: {
            type: "uri",
            label: "Mở form",
            uri: LIFF_URL
          }
        },
        {
          type: "action",
          action: {
            type: "message",
            label: "Trợ giúp",
            text: "/help"
          }
        }
      ]
    }
  };

  replyMessages(token, [flexMsg], "LINE giao form flex reply");
}


// ==========================================
// HÀM LƯU ẢNH BASE64 TỪ LIFF VÀO GOOGLE DRIVE
// ==========================================
function saveLiffImageToDrive(imageFile) {
  if (!imageFile || !imageFile.dataUrl) return "";

  var folderName = "BOT - LINE";
  var folders = DriveApp.getFoldersByName(folderName);
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(folderName);
  folder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  var contentType = imageFile.type || imageFile.dataUrl.substring(5, imageFile.dataUrl.indexOf(';'));
  var base64 = imageFile.dataUrl.split(',')[1];
  var bytes = Utilities.base64Decode(base64);
  var safeName = imageFile.name || ("liff-upload-" + new Date().getTime() + ".jpg");

  var blob = Utilities.newBlob(bytes, contentType, safeName);
  var file = folder.createFile(blob);
  var fileId = file.getId();

  var directLink = "https://lh3.googleusercontent.com/d/" + fileId;

  var sheet = getSpreadsheet().getSheetByName("Link_img");
  if (sheet) sheet.appendRow([safeName, directLink]);

  return directLink;
}

// ==========================================
// HÀM TẠO VÀ CẤU HÌNH RICH MENU
// ==========================================
function SETUP_RICH_MENU() {
  var url = "https://api.line.me/v2/bot/richmenu";

  var payload = {
    size: {
      width: 2500,
      height: 1686
    },
    selected: true,
    name: "BOT NHAC VIEC",
    chatBarText: "Menu",
    areas: [
      {
        bounds: { x: 0, y: 0, width: 833, height: 843 },
        action: {
          type: "uri",
          label: "Giao việc",
          uri: LIFF_URL
        }
      },
      {
        bounds: { x: 833, y: 0, width: 834, height: 843 },
        action: {
          type: "message",
          label: "Hôm nay",
          text: "/tthomnay"
        }
      },
      {
        bounds: { x: 1667, y: 0, width: 833, height: 843 },
        action: {
          type: "message",
          label: "7 ngày",
          text: "/tt7ngay"
        }
      },
      {
        bounds: { x: 0, y: 843, width: 833, height: 843 },
        action: {
          type: "message",
          label: "Lấy ID",
          text: "/id"
        }
      },
      {
        bounds: { x: 833, y: 843, width: 834, height: 843 },
        action: {
          type: "message",
          label: "Hướng dẫn",
          text: "/hd"
        }
      },
      {
        bounds: { x: 1667, y: 843, width: 833, height: 843 },
        action: {
          type: "message",
          label: "Trợ giúp",
          text: "/help"
        }
      }
    ]
  };

  var res = UrlFetchApp.fetch(url, {
    method: "post",
    headers: {
      Authorization: "Bearer " + TOKEN,
      "Content-Type": "application/json"
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  var code = res.getResponseCode();
  var body = res.getContentText();
  writeLog("Create rich menu: " + code + " | " + body, code >= 200 && code < 300 ? "INFO" : "ERROR");

  if (code < 200 || code >= 300) {
    throw new Error("Tạo rich menu lỗi: " + body);
  }

  var data = JSON.parse(body);
  PropertiesService.getScriptProperties().setProperty("RICH_MENU_ID", data.richMenuId);

  SpreadsheetApp.getUi().alert("✅ Đã tạo Rich Menu thành công!\nID: " + data.richMenuId);
}

function UPLOAD_RICH_MENU_IMAGE_FROM_DRIVE() {
  var ui = SpreadsheetApp.getUi();
  var props = PropertiesService.getScriptProperties();
  var richMenuId = props.getProperty("RICH_MENU_ID");

  if (!richMenuId) {
    ui.alert("❌ Chưa có RICH_MENU_ID. Vui lòng bấm Tạo Rich Menu trước.");
    return;
  }

  var input = ui.prompt(
    "Upload ảnh Rich Menu",
    "Dán Google Drive File ID hoặc link ảnh Google Drive:",
    ui.ButtonSet.OK_CANCEL
  );

  if (input.getSelectedButton() !== ui.Button.OK) return;

  var raw = input.getResponseText().trim();
  if (!raw) {
    ui.alert("❌ Bạn chưa nhập link hoặc File ID ảnh.");
    return;
  }

  var fileId = raw;

  var match = raw.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (match && match[1]) {
    fileId = match[1];
  } else {
    var matchId = raw.match(/id=([a-zA-Z0-9_-]+)/);
    if (matchId && matchId[1]) {
      fileId = matchId[1];
    }
  }

  try {
    var file = DriveApp.getFileById(fileId);
    var blob = file.getBlob();
    var contentType = blob.getContentType();

    if (contentType !== "image/png" && contentType !== "image/jpeg") {
      ui.alert("❌ Ảnh phải là PNG hoặc JPG/JPEG.\nLoại hiện tại: " + contentType);
      return;
    }

    var url = "https://api-data.line.me/v2/bot/richmenu/" + richMenuId + "/content";

    var res = UrlFetchApp.fetch(url, {
      method: "post",
      headers: {
        Authorization: "Bearer " + TOKEN,
        "Content-Type": contentType
      },
      payload: blob.getBytes(),
      muteHttpExceptions: true
    });

    var code = res.getResponseCode();
    var body = res.getContentText();
    writeLog("Upload rich menu image response: " + code + " | " + body, code >= 200 && code < 300 ? "INFO" : "ERROR");

    if (code < 200 || code >= 300) {
      ui.alert("❌ Upload ảnh Rich Menu lỗi:\nHTTP " + code + "\n" + body);
      return;
    }

    ui.alert("✅ Đã upload ảnh Rich Menu thành công.\nBấm tiếp: Đặt Rich Menu mặc định.");
  } catch (e) {
    ui.alert("❌ Không tìm thấy hoặc không đọc được ảnh trên Google Drive:\n" + e.toString());
  }
}

function SET_DEFAULT_RICH_MENU() {
  var richMenuId = PropertiesService.getScriptProperties().getProperty("RICH_MENU_ID");
  if (!richMenuId) throw new Error("Chưa có RICH_MENU_ID.");

  var res = UrlFetchApp.fetch("https://api.line.me/v2/bot/user/all/richmenu/" + richMenuId, {
    method: "post",
    headers: { Authorization: "Bearer " + TOKEN },
    muteHttpExceptions: true
  });

  writeLog("Set default rich menu: " + res.getResponseCode() + " | " + res.getContentText(), "INFO");
  SpreadsheetApp.getUi().alert("✅ Đã đặt Rich Menu mặc định cho bot.");
}

function replyHuongDanBot(token) {
  var text =
    "🤖 GIỚI THIỆU BOT NHẮC VIỆC\n\n" +
    "Bot dùng để giao việc, nhắc việc và theo dõi tương tác trong nhóm LINE.\n\n" +
    "📝 Giao việc:\n" +
    "Quản lý mở form để tạo công việc, chọn nhóm nhận, người phụ trách, thời gian nhắc và hình thức xác nhận.\n\n" +
    "🔔 Nhắc việc tự động:\n" +
    "Đến giờ, bot tự gửi thông báo công việc vào nhóm.\n\n" +
    "✅ Xác nhận hoàn tất:\n" +
    "Nhân viên bấm Hoàn tất hoặc gửi ảnh nghiệm thu, trạng thái sẽ được cập nhật vào Google Sheet.\n\n" +
    "📊 Theo dõi tương tác:\n" +
    "Bot ghi nhận tin nhắn, sticker, ảnh và báo cáo tương tác hôm nay hoặc 7 ngày.\n\n" +
    "📌 Lệnh nhanh:\n" +
    "/gv - Mở form giao việc\n" +
    "/id - Lấy ID nhóm/cá nhân\n" +
    "/tthomnay - Tương tác hôm nay\n" +
    "/tt7ngay - Tương tác 7 ngày\n" +
    "/help - Xem cú pháp";

  sendLineReply(token, text);
}


// ==========================================
// TEST NHANH LINK LIFF TRONG APPS SCRIPT
// ==========================================
function TEST_LIFF_URL() {
  SpreadsheetApp.getUi().alert(
    "LIFF URL hiện tại:\n" + LIFF_URL +
    "\n\nNếu bấm trong LINE báo 'Lỗi hệ thống', hãy kiểm tra trong LINE Developers:" +
    "\n1. LIFF ID có đúng không" +
    "\n2. Endpoint URL của LIFF có đúng Web App URL đang deploy không" +
    "\n3. Web App đã deploy New version chưa" +
    "\n4. Execute as: Me, Who has access: Anyone"
  );
}

